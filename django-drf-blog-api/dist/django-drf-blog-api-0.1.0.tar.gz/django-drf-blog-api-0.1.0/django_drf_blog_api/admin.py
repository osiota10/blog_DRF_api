from . models import *
from django.contrib import admin


admin.site.register(Category)
admin.site.register(Tag)
admin.site.register(Keyword)
admin.site.register(Post)
admin.site.register(Comment)
admin.site.register(Like)
