from django.db import models
from django.conf import settings
from django.contrib.contenttypes.fields import GenericForeignKey
from django.contrib.contenttypes.models import ContentType
from django_ckeditor_5.fields import CKEditor5Field
from django.utils.html import strip_tags


class Category(models.Model):
    name = models.CharField(max_length=50)

    def __str__(self):
        return self.name


class Tag(models.Model):
    name = models.CharField(max_length=50)

    def __str__(self):
        return self.name


class Keyword(models.Model):
    name = models.CharField(max_length=50)

    def __str__(self):
        return self.name


class Author(models.Model):
    user = models.OneToOneField(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='author_profile')
    role = models.CharField(max_length=100, default='Author', blank=True, null=True)

    def __str__(self):
        return f"{self.user} ({self.role})"


class Post(models.Model):
    title = models.CharField(max_length=200)
    content = CKEditor5Field('Text', config_name='extends')
    excerpt = models.TextField(blank=True, null=True, help_text="Short summary of the post")
    read_time = models.PositiveIntegerField(default=0, help_text="Estimated read time in minutes")
    featured_media = models.ForeignKey(
        'media_library.MediaAsset', on_delete=models.SET_NULL, blank=True, null=True, related_name='featured_posts',
        help_text="Linked MediaAsset from media_library"
    )
    featured_image_url = models.URLField(blank=True, null=True, help_text="Direct URL to external featured image")
    featured_image_url_caption = models.TextField(
        blank=True, null=True, help_text="Caption or credit text for the featured image"
    )
    pub_date = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    author = models.ForeignKey(
        Author, related_name='posts', on_delete=models.CASCADE, null=True, blank=True)

    @property
    def featured_image(self):
        """Returns the media asset URL if available, otherwise external image URL."""
        if self.featured_media:
            return self.featured_media.url
        return self.featured_image_url
    category = models.ForeignKey(
        Category, related_name='post_category', on_delete=models.SET_NULL, blank=True, null=True)
    tags = models.ManyToManyField(
        Tag, related_name='post_tag', blank=True)
    keywords = models.ManyToManyField(
        Keyword, related_name='post_keyword', blank=True)
    slug = models.SlugField(max_length=250, blank=True, null=True)

    def __str__(self):
        return self.title

    def safe_post_content_html(self):
        return strip_tags(self.content)


class Comment(models.Model):
    post = models.ForeignKey(Post, on_delete=models.CASCADE)
    user = models.ForeignKey(settings.AUTH_USER_MODEL, related_name='comment_user',
                             on_delete=models.CASCADE)
    comment = models.TextField()
    parent = models.ForeignKey(
        'self', null=True, blank=True, related_name='replies', on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return f"Comment by {self.user} on {self.post} at {self.created_at}"


class Like(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL,
                             on_delete=models.CASCADE)
    content_type = models.ForeignKey(ContentType, on_delete=models.CASCADE)
    object_id = models.PositiveIntegerField()
    content_object = GenericForeignKey('content_type', 'object_id')
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Like by {self.user} on {self.content_object} at {self.created_at}"
