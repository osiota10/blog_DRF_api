from rest_framework import serializers
from django.contrib.auth import get_user_model
from .models import *
from media_library.models import MediaAsset
from media_library.serializers import MediaAssetSerializer


class ContactFormSerializer(serializers.ModelSerializer):
    class Meta:
        model = ContactForm
        fields = '__all__'


class EmailSubcriptionSerializer(serializers.ModelSerializer):
    class Meta:
        model = EmailSubcription
        fields = '__all__'


class OurClientSerializer(serializers.ModelSerializer):
    logo_media = MediaAssetSerializer(read_only=True)
    logo_media_id = serializers.PrimaryKeyRelatedField(
        queryset=MediaAsset.objects.all(), write_only=True, required=False, allow_null=True, source='logo_media'
    )

    class Meta:
        model = OurClient
        fields = ('id', 'name_of_client', 'logo_media', 'logo_media_id', 'logo_url', 'logo', 'get_logo_url')


class OurSponsorSerializer(serializers.ModelSerializer):
    logo_media = MediaAssetSerializer(read_only=True)
    logo_media_id = serializers.PrimaryKeyRelatedField(
        queryset=MediaAsset.objects.all(), write_only=True, required=False, allow_null=True, source='logo_media'
    )

    class Meta:
        model = OurSponsor
        fields = ('id', 'name_of_sponsor', 'logo_media', 'logo_media_id', 'logo_url', 'logo', 'get_logo_url')


class ServiceCategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = ServiceCategory
        fields = '__all__'


class ProductCategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = ProductCategory
        fields = '__all__'


class StatSerializer(serializers.ModelSerializer):
    class Meta:
        model = Stat
        fields = '__all__'


class FaqSerializer(serializers.ModelSerializer):
    class Meta:
        model = FAQ
        fields = '__all__'


class ServiceSerializer(serializers.ModelSerializer):
    category = ServiceCategorySerializer(many=True, read_only=True)
    category_ids = serializers.PrimaryKeyRelatedField(
        queryset=ServiceCategory.objects.all(), many=True, write_only=True, required=False, source='category'
    )
    image_media = MediaAssetSerializer(read_only=True)
    image_media_id = serializers.PrimaryKeyRelatedField(
        queryset=MediaAsset.objects.all(), write_only=True, required=False, allow_null=True, source='image_media'
    )
    faqs = FaqSerializer(many=True, read_only=True)

    class Meta:
        model = Service
        fields = (
            'id', 'title', 'description', 'image_media', 'image_media_id', 'image_url', 'image',
            'slug', 'category', 'category_ids', 'get_image_url', 'faqs', 'safe_description_html'
        )


class ProductSerializer(serializers.ModelSerializer):
    category = ProductCategorySerializer(many=True, read_only=True)
    category_ids = serializers.PrimaryKeyRelatedField(
        queryset=ProductCategory.objects.all(), many=True, write_only=True, required=False, source='category'
    )
    image_media = MediaAssetSerializer(read_only=True)
    image_media_id = serializers.PrimaryKeyRelatedField(
        queryset=MediaAsset.objects.all(), write_only=True, required=False, allow_null=True, source='image_media'
    )
    hero_image_media = MediaAssetSerializer(read_only=True)
    hero_image_media_id = serializers.PrimaryKeyRelatedField(
        queryset=MediaAsset.objects.all(), write_only=True, required=False, allow_null=True, source='hero_image_media'
    )

    class Meta:
        model = Product
        fields = (
            'id', 'title', 'description', 'image_media', 'image_media_id', 'image_url', 'image',
            'hero_image_media', 'hero_image_media_id', 'hero_image_url', 'hero_image', 'hero_snippet',
            'category', 'category_ids', 'slug', 'get_image_url', 'get_hero_image_url', 'safe_description_html'
        )


class TestimonialSerializer(serializers.ModelSerializer):
    image_media = MediaAssetSerializer(read_only=True)
    image_media_id = serializers.PrimaryKeyRelatedField(
        queryset=MediaAsset.objects.all(), write_only=True, required=False, allow_null=True, source='image_media'
    )

    class Meta:
        model = Testimonial
        fields = ('id', 'name', 'position', 'message', 'image_media', 'image_media_id', 'image_url', 'image', 'get_image_url')


class SocialUrlSerializer(serializers.ModelSerializer):
    class Meta:
        model = SocialUrl
        fields = '__all__'


class OurTeamSerializer(serializers.ModelSerializer):
    image_media = MediaAssetSerializer(read_only=True)
    image_media_id = serializers.PrimaryKeyRelatedField(
        queryset=MediaAsset.objects.all(), write_only=True, required=False, allow_null=True, source='image_media'
    )
    user_id = serializers.PrimaryKeyRelatedField(
        queryset=get_user_model().objects.all(), write_only=True, required=False, allow_null=True, source='user'
    )
    user_details = serializers.SerializerMethodField(read_only=True)
    display_name = serializers.CharField(read_only=True)
    display_phone_number = serializers.CharField(read_only=True)

    def get_user_details(self, obj):
        if obj.user:
            return {
                'id': obj.user.id,
                'email': getattr(obj.user, 'email', ''),
                'first_name': getattr(obj.user, 'first_name', ''),
                'last_name': getattr(obj.user, 'last_name', ''),
            }
        return None

    class Meta:
        model = OurTeam
        fields = (
            'id', 'user', 'user_id', 'user_details', 'name', 'phone_number',
            'display_name', 'display_phone_number', 'position', 'bio',
            'image_media', 'image_media_id', 'image_url', 'image', 'get_image_url',
            'facebook_url', 'instagram_url', 'twitter_url', 'linkedin_url', 'github_url'
        )


class CompanyInfoSerializer(serializers.ModelSerializer):
    company_social = SocialUrlSerializer(read_only=True)
    company_faqs = FaqSerializer(many=True, read_only=True)
    logo_media = MediaAssetSerializer(read_only=True)
    logo_media_id = serializers.PrimaryKeyRelatedField(
        queryset=MediaAsset.objects.all(), write_only=True, required=False, allow_null=True, source='logo_media'
    )
    site_page_header_image_media = MediaAssetSerializer(read_only=True)
    site_page_header_image_media_id = serializers.PrimaryKeyRelatedField(
        queryset=MediaAsset.objects.all(), write_only=True, required=False, allow_null=True, source='site_page_header_image_media'
    )

    class Meta:
        model = CompanyInfo
        fields = (
            'id', 'company_name', 'company_address', 'telephone', 'telephone_2', 'telephone_3',
            'email', 'email_2', 'email_3', 'about_company', 'return_policy', 'term_and_conditions',
            'privacy_policy', 'company_social', 'company_faqs',
            'site_page_header_image_media', 'site_page_header_image_media_id', 'site_page_header_image', 'get_page_header_image',
            'logo_media', 'logo_media_id', 'logo', 'get_logo', 'ceo_statment'
        )


class CoreValueSerializer(serializers.ModelSerializer):
    pic_media = MediaAssetSerializer(read_only=True)
    pic_media_id = serializers.PrimaryKeyRelatedField(
        queryset=MediaAsset.objects.all(), write_only=True, required=False, allow_null=True, source='pic_media'
    )

    class Meta:
        model = CoreValue
        fields = ('id', 'title', 'description', 'pic_media', 'pic_media_id', 'pic_url', 'pic')


class EventSerializer(serializers.ModelSerializer):
    image_media = MediaAssetSerializer(read_only=True)
    image_media_id = serializers.PrimaryKeyRelatedField(
        queryset=MediaAsset.objects.all(), write_only=True, required=False, allow_null=True, source='image_media'
    )

    class Meta:
        model = Event
        fields = (
            'id', 'title', 'body', 'safe_body_html', 'image_media', 'image_media_id', 'image_url', 'image',
            'get_image_url', 'event_date', 'date_added', 'slug'
        )


class HeroSectionSerializer(serializers.ModelSerializer):
    image_media = MediaAssetSerializer(read_only=True)
    image_media_id = serializers.PrimaryKeyRelatedField(
        queryset=MediaAsset.objects.all(), write_only=True, required=False, allow_null=True, source='image_media'
    )

    class Meta:
        model = HeroSection
        fields = ('id', 'title', 'description', 'image_media', 'image_media_id', 'image_url', 'image', 'get_image_url')

