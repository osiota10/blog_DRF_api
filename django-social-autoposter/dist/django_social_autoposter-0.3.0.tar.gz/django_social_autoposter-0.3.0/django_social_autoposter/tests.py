from django.test import TestCase
from django.contrib.auth import get_user_model
from rest_framework.test import APIClient
from rest_framework import status
import unittest
from unittest.mock import patch, MagicMock

from .models import SocialPlatformConfig, SocialBroadcast, SocialPostLog, SocialDirectMessage
from .services import SocialBroadcastService, SocialMessagingService, get_platform_credentials
from .adapters import (
    FacebookAdapter, InstagramAdapter, TwitterAdapter, LinkedInAdapter,
    ThreadsAdapter, TikTokAdapter, WhatsAppAdapter
)

User = get_user_model()


class SocialAutoPosterModelAndServiceTests(TestCase):
    def setUp(self):
        self.user = User.objects.create_superuser(
            email='socialtester@example.com', password='password123'
        )

    def test_platform_credentials_db_and_fallback(self):
        # 1. Fallback when no DB row
        creds = get_platform_credentials('facebook')
        self.assertIsInstance(creds, dict)

        # 2. DB override takes precedence
        config = SocialPlatformConfig.objects.create(
            platform='facebook',
            is_enabled=True,
            page_or_account_id='page_123',
            access_token='token_abc'
        )
        creds_db = get_platform_credentials('facebook')
        self.assertTrue(creds_db['enabled'])
        self.assertEqual(creds_db['page_or_account_id'], 'page_123')
        self.assertEqual(creds_db['access_token'], 'token_abc')

        # 3. Disable platform in DB
        config.is_enabled = False
        config.save()
        creds_disabled = get_platform_credentials('facebook')
        self.assertFalse(creds_disabled['enabled'])

    @patch('django_social_autoposter.adapters.facebook.FacebookAdapter.publish')
    @patch('django_social_autoposter.adapters.twitter.TwitterAdapter.publish')
    def test_broadcast_service_multiple_platforms(self, mock_twitter_publish, mock_fb_publish):
        mock_fb_publish.return_value = {
            'success': True,
            'post_id': 'fb_post_999',
            'post_url': 'https://facebook.com/fb_post_999',
            'error': None,
            'raw_response': {'id': 'fb_post_999'}
        }
        mock_twitter_publish.return_value = {
            'success': True,
            'post_id': 'tweet_888',
            'post_url': 'https://x.com/i/web/status/tweet_888',
            'error': None,
            'raw_response': {'data': {'id': 'tweet_888'}}
        }

        # Enable facebook and twitter
        SocialPlatformConfig.objects.create(
            platform='facebook', is_enabled=True,
            page_or_account_id='fb_page_1', access_token='fb_token_1'
        )
        SocialPlatformConfig.objects.create(
            platform='twitter', is_enabled=True,
            bearer_token='x_token_1'
        )

        broadcast = SocialBroadcastService.broadcast(
            title="Launch Day!",
            message="We are thrilled to announce our new platform launch.",
            link_url="https://example.com/launch",
            image_url="https://example.com/cover.png",
            platforms=['facebook', 'twitter'],
            source_instance=self.user,
            async_dispatch=False
        )

        self.assertEqual(broadcast.title, "Launch Day!")
        self.assertEqual(broadcast.content_object, self.user)
        self.assertEqual(broadcast.logs.count(), 2)

        fb_log = broadcast.logs.get(platform='facebook')
        self.assertEqual(fb_log.status, 'published')
        self.assertEqual(fb_log.external_post_id, 'fb_post_999')

        tw_log = broadcast.logs.get(platform='twitter')
        self.assertEqual(tw_log.status, 'published')
        self.assertEqual(tw_log.external_post_id, 'tweet_888')

    @patch('requests.post')
    def test_twitter_adapter_oauth1_user_context(self, mock_post):
        # 1. Missing keys returns descriptive error
        adapter_missing = TwitterAdapter({
            'api_key': 'key_123',
            'api_secret': 'sec_456'
            # missing access_token and access_token_secret
        })
        fake_broadcast = SocialBroadcast.objects.create(message="Test Tweet")
        res_missing = adapter_missing.publish(fake_broadcast)
        self.assertFalse(res_missing['success'])
        self.assertIn("Missing Twitter OAuth 1.0a credentials", res_missing['error'])

        # 2. Complete 4 keys successfully executes with OAuth1
        mock_response = unittest.mock.MagicMock()
        mock_response.status_code = 201
        mock_response.content = b'{"data": {"id": "1850000000000000000"}}'
        mock_response.json.return_value = {"data": {"id": "1850000000000000000"}}
        mock_post.return_value = mock_response

        adapter_valid = TwitterAdapter({
            'api_key': 'my_key',
            'api_secret': 'my_secret',
            'access_token': 'my_token',
            'access_token_secret': 'my_token_secret'
        })
        res_valid = adapter_valid.publish(fake_broadcast)
        self.assertTrue(res_valid['success'])
        self.assertEqual(res_valid['post_id'], "1850000000000000000")
        self.assertIn("x.com/i/web/status/1850000000000000000", res_valid['post_url'])

        # 3. 403 Forbidden with App-Only message gives explicit diagnostics
        mock_403 = unittest.mock.MagicMock()
        mock_403.status_code = 403
        mock_403.content = b'{"detail": "Authenticating with OAuth 2.0 Application-Only is forbidden for this endpoint."}'
        mock_403.json.return_value = {"detail": "Authenticating with OAuth 2.0 Application-Only is forbidden for this endpoint."}
        mock_post.return_value = mock_403

        adapter_bearer = TwitterAdapter({'bearer_token': 'app_only_bearer'})
        res_403 = adapter_bearer.publish(fake_broadcast)
        self.assertFalse(res_403['success'])
        self.assertIn("Bearer Token alone (App-Only) is forbidden", res_403['error'])

    @patch('requests.post')
    def test_threads_adapter_publish(self, mock_post):
        fake_broadcast = SocialBroadcast.objects.create(
            title="Threads News",
            message="Exploring Meta Threads API",
            link_url="https://example.com/threads",
            image_url="https://example.com/image.jpg"
        )

        # 1. Missing credentials
        adapter_missing = ThreadsAdapter({})
        res_missing = adapter_missing.publish(fake_broadcast)
        self.assertFalse(res_missing['success'])
        self.assertIn("Missing Threads User ID", res_missing['error'])

        # 2. Successful 2-step publish
        mock_container_res = MagicMock()
        mock_container_res.status_code = 200
        mock_container_res.content = b'{"id": "c_threads_123"}'
        mock_container_res.json.return_value = {"id": "c_threads_123"}

        mock_publish_res = MagicMock()
        mock_publish_res.status_code = 200
        mock_publish_res.content = b'{"id": "p_threads_999"}'
        mock_publish_res.json.return_value = {"id": "p_threads_999"}

        mock_post.side_effect = [mock_container_res, mock_publish_res]

        adapter_valid = ThreadsAdapter({
            'page_or_account_id': 'threads_user_1',
            'access_token': 'threads_tok_abc'
        })
        res_valid = adapter_valid.publish(fake_broadcast)
        self.assertTrue(res_valid['success'])
        self.assertEqual(res_valid['post_id'], 'p_threads_999')
        self.assertIn('threads.net/post/p_threads_999', res_valid['post_url'])

    @patch('requests.post')
    def test_tiktok_adapter_publish(self, mock_post):
        # 1. Missing access token
        adapter_missing = TikTokAdapter({})
        broadcast_no_image = SocialBroadcast.objects.create(message="TikTok Text Only")
        res_missing = adapter_missing.publish(broadcast_no_image)
        self.assertFalse(res_missing['success'])
        self.assertIn("Missing TikTok Access Token", res_missing['error'])

        # 2. Missing image URL
        adapter_valid = TikTokAdapter({'access_token': 'tiktok_token_xyz'})
        res_no_media = adapter_valid.publish(broadcast_no_image)
        self.assertFalse(res_no_media['success'])
        self.assertIn("TikTok Content Posting API requires a media URL", res_no_media['error'])

        # 3. Successful photo direct post
        broadcast_with_media = SocialBroadcast.objects.create(
            title="TikTok Photo Post",
            message="Check out our visual announcement",
            image_url="https://example.com/banner.jpg"
        )
        mock_res = MagicMock()
        mock_res.status_code = 200
        mock_res.content = b'{"data": {"publish_id": "v_pub_tiktok_456"}, "error": {"code": "ok"}}'
        mock_res.json.return_value = {
            "data": {"publish_id": "v_pub_tiktok_456"},
            "error": {"code": "ok"}
        }
        mock_post.return_value = mock_res

        res_ok = adapter_valid.publish(broadcast_with_media)
        self.assertTrue(res_ok['success'])
        self.assertEqual(res_ok['post_id'], 'v_pub_tiktok_456')



class SocialAutoPosterAPITests(TestCase):
    def setUp(self):
        self.client = APIClient()
        self.user = User.objects.create_superuser(
            email='apiadmin@example.com', password='password123'
        )
        self.client.force_authenticate(user=self.user)

    def test_social_platform_config_api(self):
        # Create config
        res = self.client.post('/social/configs/', {
            'platform': 'linkedin',
            'is_enabled': True,
            'page_or_account_id': '12345678',
            'access_token': 'li_token_sec'
        })
        self.assertEqual(res.status_code, status.HTTP_201_CREATED)
        self.assertEqual(res.data['platform'], 'linkedin')

        # List configs
        res_list = self.client.get('/social/configs/')
        self.assertEqual(res_list.status_code, status.HTTP_200_OK)
        self.assertEqual(len(res_list.data), 1)

    @patch('django_social_autoposter.services.SocialBroadcastService.broadcast')
    def test_social_broadcast_api_post(self, mock_broadcast):
        fake_broadcast = SocialBroadcast.objects.create(
            title="API Broadcast",
            message="Posting from REST API",
            link_url="https://example.com/blog",
            target_platforms=['facebook', 'twitter']
        )
        mock_broadcast.return_value = fake_broadcast

        res = self.client.post('/social/broadcast/', {
            'title': 'API Broadcast',
            'message': 'Posting from REST API',
            'link_url': 'https://example.com/blog',
            'platforms': ['facebook', 'twitter']
        })
        self.assertEqual(res.status_code, status.HTTP_201_CREATED)
        self.assertEqual(res.data['title'], 'API Broadcast')

        # List broadcasts
        res_list = self.client.get('/social/broadcast/')
        self.assertEqual(res_list.status_code, status.HTTP_200_OK)
        self.assertEqual(len(res_list.data), 1)

    @patch('django_social_autoposter.services.SocialMessagingService.send_message')
    def test_social_message_send_api(self, mock_send_message):
        mock_dm = SocialDirectMessage.objects.create(
            platform='whatsapp',
            recipient_id='+1234567890',
            message='Hello there!',
            direction='outbound',
            status='delivered',
            external_message_id='wamid.12345'
        )
        mock_send_message.return_value = mock_dm

        payload = {
            'platform': 'whatsapp',
            'recipient_id': '+1234567890',
            'message': 'Hello there!'
        }
        res = self.client.post('/social/messages/send/', payload, format='json')
        self.assertEqual(res.status_code, status.HTTP_201_CREATED)
        self.assertEqual(res.data['platform'], 'whatsapp')
        self.assertEqual(res.data['recipient_id'], '+1234567890')
        self.assertEqual(res.data['status'], 'delivered')
        self.assertEqual(res.data['external_message_id'], 'wamid.12345')

    def test_social_message_list_and_detail_api(self):
        dm1 = SocialDirectMessage.objects.create(
            platform='whatsapp',
            recipient_id='15551234567',
            message='WhatsApp Msg',
            direction='outbound',
            status='delivered'
        )
        dm2 = SocialDirectMessage.objects.create(
            platform='facebook',
            recipient_id='fb_psid_456',
            message='FB Msg',
            direction='outbound',
            status='failed'
        )

        # List all
        res = self.client.get('/social/messages/')
        self.assertEqual(res.status_code, status.HTTP_200_OK)
        self.assertEqual(len(res.data), 2)

        # Filter by platform
        res_filtered = self.client.get('/social/messages/?platform=whatsapp')
        self.assertEqual(res_filtered.status_code, status.HTTP_200_OK)
        self.assertEqual(len(res_filtered.data), 1)
        self.assertEqual(res_filtered.data[0]['recipient_id'], '15551234567')

        # Retrieve detail
        res_detail = self.client.get(f'/social/messages/{dm1.id}/')
        self.assertEqual(res_detail.status_code, status.HTTP_200_OK)
        self.assertEqual(res_detail.data['id'], dm1.id)
        self.assertEqual(res_detail.data['message'], 'WhatsApp Msg')


class SocialMessagingAdapterTests(TestCase):
    @patch('requests.post')
    def test_facebook_adapter_dm(self, mock_post):
        # 1. Missing credentials
        adapter_missing = FacebookAdapter({})
        res_missing = adapter_missing.send_direct_message('12345', 'Hello')
        self.assertFalse(res_missing['success'])
        self.assertIn("Missing Facebook Page Access Token", res_missing['error'])

        # 2. Successful text message
        mock_res = MagicMock()
        mock_res.status_code = 200
        mock_res.content = b'{"recipient_id": "12345", "message_id": "mid.fb.123"}'
        mock_res.json.return_value = {"recipient_id": "12345", "message_id": "mid.fb.123"}
        mock_post.return_value = mock_res

        adapter = FacebookAdapter({'access_token': 'fb_page_tok'})
        res = adapter.send_direct_message('12345', 'Hello FB user')
        self.assertTrue(res['success'])
        self.assertEqual(res['message_id'], 'mid.fb.123')

        # 3. 24-hour customer window error
        mock_err = MagicMock()
        mock_err.status_code = 400
        mock_err.content = b'{"error": {"message": "Message failed to send", "code": 10, "error_subcode": 2018001}}'
        mock_err.json.return_value = {
            "error": {"message": "Message failed to send", "code": 10, "error_subcode": 2018001}
        }
        mock_post.return_value = mock_err
        res_err = adapter.send_direct_message('12345', 'Outside window')
        self.assertFalse(res_err['success'])
        self.assertIn("24-hour standard messaging window", res_err['error'])

    @patch('requests.post')
    def test_instagram_adapter_dm(self, mock_post):
        # 1. Missing credentials
        adapter_missing = InstagramAdapter({})
        res_missing = adapter_missing.send_direct_message('ig_user_1', 'Hi IG')
        self.assertFalse(res_missing['success'])

        # 2. Success send
        mock_res = MagicMock()
        mock_res.status_code = 200
        mock_res.content = b'{"recipient_id": "ig_user_1", "message_id": "mid.ig.999"}'
        mock_res.json.return_value = {"recipient_id": "ig_user_1", "message_id": "mid.ig.999"}
        mock_post.return_value = mock_res

        adapter = InstagramAdapter({'access_token': 'ig_tok_abc'})
        res = adapter.send_direct_message('ig_user_1', 'Hi IG')
        self.assertTrue(res['success'])
        self.assertEqual(res['message_id'], 'mid.ig.999')

    @patch('requests.post')
    def test_twitter_adapter_dm(self, mock_post):
        # 1. Missing credentials
        adapter_missing = TwitterAdapter({})
        res_missing = adapter_missing.send_direct_message('x_user_123', 'Hey on X')
        self.assertFalse(res_missing['success'])
        self.assertIn("Direct messaging requires User Context", res_missing['error'])

        # 2. Success send via OAuth1
        mock_res = MagicMock()
        mock_res.status_code = 201
        mock_res.content = b'{"data": {"dm_event_id": "evt_tw_12345", "dm_conversation_id": "conv_999"}}'
        mock_res.json.return_value = {
            "data": {"dm_event_id": "evt_tw_12345", "dm_conversation_id": "conv_999"}
        }
        mock_post.return_value = mock_res

        adapter = TwitterAdapter({
            'api_key': 'k', 'api_secret': 's',
            'access_token': 't', 'access_token_secret': 'ts'
        })
        res = adapter.send_direct_message('x_user_123', 'Hey on X')
        self.assertTrue(res['success'])
        self.assertEqual(res['message_id'], 'evt_tw_12345')
        self.assertEqual(res['conversation_id'], 'conv_999')

    @patch('requests.post')
    def test_whatsapp_adapter(self, mock_post):
        # 1. Missing credentials
        adapter_missing = WhatsAppAdapter({})
        res_missing = adapter_missing.send_direct_message('+1 (555) 000-1111', 'Hello')
        self.assertFalse(res_missing['success'])
        self.assertIn("Missing WhatsApp credentials", res_missing['error'])

        # 2. Phone normalization and text message send
        mock_res = MagicMock()
        mock_res.status_code = 200
        mock_res.content = b'{"messages": [{"id": "wamid.HBgL..."}]}'
        mock_res.json.return_value = {"messages": [{"id": "wamid.HBgL..."}]}
        mock_post.return_value = mock_res

        adapter = WhatsAppAdapter({
            'page_or_account_id': '10987654321',
            'access_token': 'wa_tok_123'
        })
        res = adapter.send_direct_message('+1 (555) 234-5678', 'Hello WhatsApp!')
        self.assertTrue(res['success'])
        self.assertEqual(res['message_id'], 'wamid.HBgL...')

        # Verify normalized phone number in request body
        call_kwargs = mock_post.call_args[1]
        self.assertEqual(call_kwargs['json']['to'], '15552345678')
        self.assertEqual(call_kwargs['json']['type'], 'text')
        self.assertEqual(call_kwargs['json']['text']['body'], 'Hello WhatsApp!')

        # 3. Media message send
        res_media = adapter.send_direct_message(
            '15552345678',
            'Image caption',
            media_url='https://example.com/receipt.pdf',
            extra_params={'media_type': 'document'}
        )
        self.assertTrue(res_media['success'])
        call_kwargs_media = mock_post.call_args[1]
        self.assertEqual(call_kwargs_media['json']['type'], 'document')
        self.assertEqual(call_kwargs_media['json']['document']['link'], 'https://example.com/receipt.pdf')

    @patch('requests.post')
    def test_linkedin_adapter_dm(self, mock_post):
        # 1. Missing access token
        adapter_missing = LinkedInAdapter({})
        res_missing = adapter_missing.send_direct_message('person_123', 'Hi on LinkedIn')
        self.assertFalse(res_missing['success'])
        self.assertIn("Missing LinkedIn Access Token", res_missing['error'])

        # 2. Successful send with URN formatting
        mock_res = MagicMock()
        mock_res.status_code = 201
        mock_res.content = b'{"value": {"conversation": "urn:li:fs_conversation:123"}, "id": "urn:li:fs_event:456"}'
        mock_res.json.return_value = {
            "value": {"conversation": "urn:li:fs_conversation:123"},
            "id": "urn:li:fs_event:456"
        }
        mock_post.return_value = mock_res

        adapter = LinkedInAdapter({'access_token': 'li_tok_abc'})
        res = adapter.send_direct_message('12345', 'Hi on LinkedIn')
        self.assertTrue(res['success'])
        self.assertEqual(res['message_id'], 'urn:li:fs_event:456')
        self.assertEqual(res['conversation_id'], 'urn:li:fs_conversation:123')

        # Verify URN formatted in payload
        call_kwargs = mock_post.call_args[1]
        recipients = call_kwargs['json']['recipients']
        self.assertEqual(recipients, ['urn:li:person:12345'])


class SocialMessagingServiceTests(TestCase):
    def test_validation(self):
        # Missing recipient
        with self.assertRaises(ValueError):
            SocialMessagingService.send_message(
                platform='whatsapp',
                recipient_id='',
                message='Hello'
            )

        # Missing both message and media_url
        with self.assertRaises(ValueError):
            SocialMessagingService.send_message(
                platform='whatsapp',
                recipient_id='12345',
                message='',
                media_url=None
            )

    @patch('django_social_autoposter.adapters.whatsapp.WhatsAppAdapter.send_direct_message')
    def test_service_execution(self, mock_send_dm):
        mock_send_dm.return_value = {
            'success': True,
            'message_id': 'wamid.success.123',
            'conversation_id': None,
            'error': None,
            'raw_response': {'id': 'wamid.success.123'}
        }

        # Enable whatsapp in DB
        SocialPlatformConfig.objects.create(
            platform='whatsapp',
            is_enabled=True,
            page_or_account_id='10987654321',
            access_token='wa_tok_valid'
        )

        dm = SocialMessagingService.send_message(
            platform='whatsapp',
            recipient_id='15551234567',
            message='Order confirmation #4321'
        )

        self.assertEqual(dm.status, 'delivered')
        self.assertEqual(dm.external_message_id, 'wamid.success.123')
        self.assertEqual(dm.direction, 'outbound')
        self.assertIsNone(dm.error_message)
